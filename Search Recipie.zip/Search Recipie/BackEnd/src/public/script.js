async function searchRecipe() {
    const query = document.getElementById("search").value.trim();
    const resultDiv = document.getElementById("result");
    const noResultDiv = document.getElementById("noResult");
    const loadingDiv = document.getElementById("loading");

    resultDiv.style.display = "none"; // Hide result container initially
    noResultDiv.style.display = "none"; // Hide no result message
    loadingDiv.style.display = "block"; // Show loading message

    if (query === "") {
        loadingDiv.style.display = "none"; // Hide loading if search is empty
        return;
    }

    try {
        const response = await fetch(`/api/recipes?q=${encodeURIComponent(query)}`);
        const data = await response.json();

        loadingDiv.style.display = "none"; // Hide loading message

        if (response.ok) {
            resultDiv.innerHTML = `
                <h2><u>${data.name}</u></h2>
                <h5>TIme to Cook : ${data.time}</h5>
                <h5>Serves : ${data.serves}</h5>
                <h3>Ingredients:</h3>
                <ul>
                    ${data.ingredients.map(ingredient => `<li class="ingredient">${ingredient}</li>`).join("")}
                </ul>
                <h3>Steps:</h3>
                <ol>
                    ${data.steps.map(step => `<li>${step}</li>`).join("")}
                </ol>
            `;
            resultDiv.style.display = "block"; // Show result container
        } else {
            noResultDiv.style.display = "block"; // Show no result message
        }
    } catch (error) {
        loadingDiv.style.display = "none"; // Hide loading message
        noResultDiv.style.display = "block"; // Show error message
        noResultDiv.innerHTML = "An error occurred while fetching the recipe.";
    }
}
