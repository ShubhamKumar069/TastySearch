import express from "express";
import fs from "fs";
import path from "path";

const app = express();
const PORT = 3000;

const dataPath = path.join(__dirname, "data", "recipes.json");

app.use(express.static(path.join(__dirname, "public")));
app.use(express.json());


app.get("/api/recipes", (req, res) => {
  const q = req.query.q?.toString().toLowerCase() || "";
  const data = JSON.parse(fs.readFileSync(dataPath, "utf-8"));

  const found = data.find((recipe: any) =>
    recipe.name.toLowerCase().includes(q)
  );

  if (!found) {
    return res.status(404).json({ message: "Recipe not found!" });
  }

  res.json(found);
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
